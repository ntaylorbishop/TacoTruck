<?php

require 'Slim/Slim.php';

$app = new Slim();

$app->get('/menu/:itemType', 'getMenuItem');

$app->run();

function getMenuItem($itemType) {
	$sql = "select * FROM menu WHERE itemType=:itemType ORDER BY tacoFixinId";
	try {
		$db = getConnection();
		$stmt = $db->prepare($sql);
$stmt->bindParam("itemType", $itemType);
$stmt->execute();
		$menu = $stmt->fetchAll(PDO::FETCH_OBJ);
		$db = null;
		echo '{"menu": ' . json_encode($menu) . '}';
	} catch(PDOException $e) {
		echo '{"error":{"text":'. $e->getMessage() . '}}';
	}
}

function getConnection() {
	$dbhost="localhost";
	$dbuser="root";
	$dbpass="jkp";
	$dbname="CSV_DB";
	$dbh = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	return $dbh;
}
?>
